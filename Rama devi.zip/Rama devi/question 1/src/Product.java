import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Product {

	Map<Integer, String> value = new HashMap<Integer, String>();

	value.add(1,"FairAndLovelyCream");value.add(2,"Lakme Lotion");value.add(3,"FairOneLotion");value.add(4,"Ponds Cream");value.add(5,"Baby Cream ");

	public static void addProductDetails() {
		
          Scanner scan=new Scanner(System.in);
			System.out.println("number of products to be add");
			int productsCount = scan.nextInt();
			for(int i=1;i<productsCount;i++) {
				System.out.println("Enter the key" +i);
			    key=values.nextInt();
				
			System.out.println("Enter the value");
	      value=values.next();
	      values.put(key,value);
		}

	public static void searchBasedOnProduct(){
			for(int i=1;i<values.size();i++) {
				System.out.println("Enter the value");	
				 value=values.next();
				 values[i];
				 Object key;
				values.put(key,value);
				 
			}

	public static void main(String[] args) {
		addProductDetails();
		searchBasedOnProduct();
	}

}
