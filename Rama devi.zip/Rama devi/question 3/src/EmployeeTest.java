import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class EmployeeTest {

	@Test
	public void calNetPayTestIf() {
		Employee emp = new Employee(23, "rama", 10000, 4);
		Assertions.assertEquals(10000, emp.calNetPay());
	}

	@Test
	public void calNetPayTestElse() {
		Employee emp = new Employee(10, "devi", 20000, 4);
		Assertions.assertEquals(20000, emp.calNetPay());
	}

}
