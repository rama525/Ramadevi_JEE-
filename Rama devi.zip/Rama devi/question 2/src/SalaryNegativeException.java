
@SuppressWarnings("serial")
public class SalaryNegativeException extends Exception {
	{
		System.out.println("Invalid Salary");
	}
}