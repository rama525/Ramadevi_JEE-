import java.util.Scanner;

public class EmployeeProgram {

	String name;
	char gender;
	String category;
	double salary;

	public static void setSalary(double salary) throws SalaryNegativeException {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter your name");
		scan.next();
		System.out.println("Enter your gender(M/F)");
		scan.next();
		System.out.println("Enter your category");
		scan.next();
		System.out.println("Enter your salary");
		scan.next();

		if (salary < 0) {
			throw new SalaryNegativeException();
		} else {
			System.out.println("Valid Salary");
		}
	}

	public static void main(String[] args) {
		try {
			setSalary(25000.00);
		} catch (SalaryNegativeException e) {
			// TODO Auto-generated catch block
			
			System.out.println("valid salary");
		}
		
	}
}
